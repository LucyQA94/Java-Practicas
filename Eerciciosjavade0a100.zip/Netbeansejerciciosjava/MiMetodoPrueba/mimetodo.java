//Mi clase en java

public class HolaMundo {

    public static void main(String args[]) {

        var usuario ="Lucía";
        var titulo = "Ingeniero";
        var union = titulo + " " + usuario;
        System.out.println("union = " + union);

        var i = 3;
        var j = 4;

        System.out.println(i + j); //Se realiza la suma de números
        System.out.println(i + j + usuario); //Evaluación de izquierda a derecha
        System.out.println(usuario + i + j); //Contexto cadena, todo es cadena
        System.out.println(usuario + (i+j)); //uso de parantesis

    }

}