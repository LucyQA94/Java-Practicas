package comandocp;
import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ComandoCP {

	public static boolean copiarFicheros(String ficheroDestino, String ficheroOrigen){
        File origen = new File(ficheroDestino);
        File destino = new File(ficheroOrigen);
        if (origen.exists()) {
            try {
                InputStream in = new FileInputStream(origen);
                OutputStream out = new FileOutputStream(destino);
                // buffer para copiar los ficheros
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
                return true;
            } catch (IOException e) {
            	System.out.println("Error de E/S");
                e.getMessage();
                return false;
            }
        } else {
            return false;
        }
	}
    public static void main(String args[]) {
        boolean result = copiarFicheros(args[0], args[1]);
        System.out.println(result ? "Fichero copiado" : "Error! No se ha podido copiar el fichero");
    }
}