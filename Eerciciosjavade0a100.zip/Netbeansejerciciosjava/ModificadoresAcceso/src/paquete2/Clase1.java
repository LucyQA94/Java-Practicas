package paquete2;

/**
 *
 * @author Lucia
 */
public class Clase1 {
    protected String atributoPublico = "Valor atributo publico";
    //si usamos protected debemos de usar SUPER, protected se puede utilizar a nivel de constructor también, ejemplo:
    
    
    protected Clase1(){
        System.out.println("Constructor Publico"); 
    }
    
    public Clase1(String arg){
        Clase1 clase1 = new Clase1("Publico");
    }
    
    protected void metodoProtected(){
        System.out.println("Metodo publico");
    }
}
