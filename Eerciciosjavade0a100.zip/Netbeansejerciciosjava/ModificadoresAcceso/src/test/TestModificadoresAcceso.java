package test;

import paquete2.Clase1;

/**
 *
 * @author Lucia
 */
public class TestModificadoresAcceso {
    public static void main(String[] args) {
        Clase1 clase1 = new Clase1();
        clase1.metodoProtected();
    }
}
