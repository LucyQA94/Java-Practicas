package test;

import enumeraciones.Dias;
import static enumeraciones.Dias.MIERCOLES;

/**
 *
 * @author Lucia
 */
public class TestEnumeraciones {
    public static void main(String[] args) {
        System.out.println("Día 1:" + Dias.LUNES);
    }
    private static void indicarDiaSemana(Dias dias){
        switch(dias){
            case LUNES:
                System.out.println("Primer día de la semana");
                break;
            case MARTES:
                System.out.println("Segundo día de la semana");
            case MIERCOLES:
                System.out.println("Tercer día de la semana");
                break;
            case JUEVES:
                System.out.println("Cuarto día de la semana");
                break;
            case VIERNES:
                System.out.println("Quinto día de la semana");
                break;
            case SABADO:
                System.out.println("Sexto día de la semana");
                break;
            case DOMINGO:
                System.out.println("Septimo día de la semana");
                break;
            default: MIERCOLES;
        }
    }
}
