package domain;

/**
 *
 * @author Lucia
 */
public class Empleado extends Persona{
//public void imprimir(){
      //  System.out.println("Metodo imprimir desde clase hija:");
    }
