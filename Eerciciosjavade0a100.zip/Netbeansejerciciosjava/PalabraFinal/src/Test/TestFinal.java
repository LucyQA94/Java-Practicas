package Test;

import domain.Persona;

/**
 *
 * @author Lucia
 */
public class TestFinal {
    public static void main(String[] args) {
        final int miVariable = 10;
        System.out.println("La variable tiene un entero de: " + miVariable);
        System.out.println("Mi constante" + Persona.MI_CONSTANTE);
        
        final Persona persona1 = new Persona();
        System.out.println("persona1 nombre:" + persona1.getNombre());
        persona1.setNombre("Carlos");
    }
}
