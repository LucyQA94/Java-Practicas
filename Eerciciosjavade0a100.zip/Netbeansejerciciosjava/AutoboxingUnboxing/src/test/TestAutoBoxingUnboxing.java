package test;
/**
 *
 * @author Lucia
 */
public class TestAutoBoxingUnboxing {
    public static void main(String[] args) {
        //Clases Envolventes de tipos primitivos
        /*
        int - Integer
        long - Long
        float - Float
        double - Double
        */
        
        Integer entero = 10;
        System.out.println("entero = " + entero);
        System.out.println("entero = " + entero.toString());
        
        int entero2 = entero;
        System.out.println("entero2 = " + entero2);

    }
}
