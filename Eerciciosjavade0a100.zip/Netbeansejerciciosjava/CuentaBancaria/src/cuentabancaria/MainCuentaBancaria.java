
package cuentabancaria;
public class MainCuentaBancaria
{
/**
 * Main de la cuenta bancaria con los datos necesarios
 * @author Lucia
 */
public static void main(String args[])
{
    CuentaBancaria cuenta = new CuentaBancaria(1234521, "Paquita Java", 100,0);
    System.out.println("Saldo: " + cuenta.getsaldo());
    cuenta.reintegro(50);
    cuenta.ingreso(100);
    System.out.println("Saldo: " + cuenta.getsaldo());
}
 
}
