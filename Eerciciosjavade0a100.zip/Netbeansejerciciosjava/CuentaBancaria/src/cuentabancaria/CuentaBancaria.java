package cuentabancaria;

/**
 *Tarea UT5 Cuenta Bancaria
 * @author Lucia
 */
public class CuentaBancaria {

//Propiedades de la clase CuentaBancaria
private long numeroDeCuenta;
private String nombreDelTitular;
private double saldo;
private double tipoInteres;

//Constructores para la clase CuentaBancaria
public CuentaBancaria(long numeroDeCuenta, String nombreDelTitular, double tipoInteres, double saldo)
{
this.numeroDeCuenta = numeroDeCuenta;
this.nombreDelTitular = nombreDelTitular;
this.saldo = saldo;
this.tipoInteres = tipoInteres;
}

//Metodos Set
public void setnumeroDeCuenta(long numeroDeCuenta)
{
    this.numeroDeCuenta = numeroDeCuenta;
}

public void setnombreDelTitular(String nombreDelTitular)
{
    this.nombreDelTitular = nombreDelTitular;
}

public void settipoInteres(double tipoInteres)
{
    this.tipoInteres = tipoInteres;
}

//Metodos Get

public long getnumeroDeCuenta()
{
    return numeroDeCuenta;
}

public String nombreDelTitular()
{
    return nombreDelTitular;
}

public double getsaldo()
{
    return saldo;
}

public double tipoInteres()
{
    return tipoInteres;
}

public void ingreso(double cantidad)
{
    if(cantidad > 0)
        saldo = saldo + cantidad;
        
    else
        System.out.println("Error, la cantidad debe ser mayor o igual a 0");
}


public void reintegro(double cantidad)
{
    if(cantidad > 0)
    {
        if(cantidad > saldo)
            System.out.println("Saldo insuficiente");
        else
            saldo = saldo - cantidad;
    }
    else
        System.out.println("Error, la cantidad debe ser mayor o igual a 0");

    }
}    

