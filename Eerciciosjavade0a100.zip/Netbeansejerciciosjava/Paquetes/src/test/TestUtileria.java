package test;
//import mx.com.globalmentoring.paquetes.*; Importa todas las clases del paquete indicado
//import mx.com.globalmentoring.paquetes.Utileria;
//import static mx.com.globalmentoring.Utileria.imprimir;
/**
 *
 * @author Lucia
 */
public class TestUtileria {
    public static void main(String[] args){
        //Utileria.imprimir("Saludos");
        //imprimir("Adios");
        mx.com.globalmentoring.paquetes.Utileria.imprimir("Adios");
    }
}
