package mx.com.globalmentoring.paquetes;
/**
 *
 * @author Lucia
 */
public class Utileria {
    public static void imprimir(String s){
        System.out.println("s = " + s);
    }
}
