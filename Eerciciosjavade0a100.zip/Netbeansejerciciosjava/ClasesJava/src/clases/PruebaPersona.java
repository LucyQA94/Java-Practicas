package clases;

/**
 *
 * @author Lucia
 */
public class PruebaPersona {
    public static void main(String[] args) {
        Persona persona1= new Persona();
        persona1.nombre = "Lucia";
        persona1.apellido ="Hidalgo";
        persona1.desplegarInformacion();
        
        Persona persona2 = new Persona();
        System.out.println("persona2 = " + persona2);
        System.out.println("persona1 = " + persona1);
        
        persona2.desplegarInformacion();
        persona2.nombre ="Karla";
        persona2.apellido = "Paquita";
        persona2.desplegarInformacion();
    }
}
