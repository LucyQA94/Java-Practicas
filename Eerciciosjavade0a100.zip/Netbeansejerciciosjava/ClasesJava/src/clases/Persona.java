package clases;
public class Persona {
    //Definicion de atributos de la clase
    String nombre;
    String genero;
    String apellido;
    String ocupacion;
    
    public void desplegarInformacion(){
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido:" + apellido);
    }
    
}
