
package clasescanner;

import java.util.Scanner;

/**
 *
 * @author Lucia Hidalgo
 */
public class ClaseScanner {

    public static void main(String[] args) {
        System.out.println("Escribe tu nombre:");
        Scanner consola = new Scanner(System.in);
       var usuario = consola.nextLine();
        System.out.println("usuario = " +  usuario);
        System.out.println("Introduzca un titulo");
        var titulo = consola.nextLine();
        System.out.println("Resultado: " + titulo + " " + usuario);
    }
    
}
