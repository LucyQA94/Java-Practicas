
package prueba3caracteres;

public class Prueba3caracteres {
    
    public static void main(String[] args) {
        var nombre="Karla";
        
        System.out.println("Nueva linea: \n" + nombre);
        System.out.println("Tabulador: \t" + nombre);
        System.out.println("Retroceso: \b\b\b"+ nombre);
        System.out.println("Comilla simple: \'" + nombre + "\'");
        System.out.println("Comilla doble:  \"" + nombre +"\"");
    }
    
}
