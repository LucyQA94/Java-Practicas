package test;

import domain.Persona;

/**
 *
 * @author Lucia
 */
public class TestBloquesInicializacion {
    public static void main(String[] args) {
        Persona persona1 = new Persona();
        System.out.println("persona1" + persona1);
        System.out.println("------------------------------------");
        //Aquí se va a ejecutar solo el bloque no estatico, el objeto constructor y además del objeto persona2
        Persona persona2 = new Persona();
        System.out.println("persona2 ="+ persona2);
    }
    
}
