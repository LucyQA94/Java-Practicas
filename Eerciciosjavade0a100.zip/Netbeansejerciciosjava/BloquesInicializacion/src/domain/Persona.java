package domain;
/**
 *
 * @author Lucia
 */
public class Persona {
    private final int idPersona;
    private static int contadorPersonas;
    
    
    static{
        //Solo se ejecuta una vez
        System.out.println("Ejecución bloque estático");
        ++Persona.contadorPersonas;
    }
    
    {
        //bloque de inicialización no estático - se ejecuta antes del constructor de nuestra clase
        //Se ejecuta todas las veces que ejecutemos el código
        System.out.println("Ejecución bloque no estático");
        this.idPersona = Persona.contadorPersonas;
    }
    
    public Persona(){
        System.out.println("Ejecucion del constructor");
    }

    public int getIdPersona() {
        return idPersona;
    }

    @Override
    public String toString() {
        return "Persona{" + "idPersona=" + idPersona + '}';
    }
    
    
}
