package pasoporreferencia;

import clases.Persona.Persona;

public class PasoPorReferencia {
    public static void main(String[] args) {
        Persona persona1 = new Persona();
        persona1.nombre = "Paquito";
        System.out.println("persona 1 nombre: " + persona1.nombre);
        cambiarValor(persona1);
        System.out.println("persona1 cambio nombre:" + persona1.nombre);
    }
    public static Persona cambiarValor(Persona persona){
        if(persona == null){
        return persona;
    }
        persona.nombre = "Karla";
        return persona;
        
    }
    
}
