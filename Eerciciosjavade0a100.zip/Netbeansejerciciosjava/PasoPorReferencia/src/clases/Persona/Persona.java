package clases.Persona;

/**
 *
 * @author Lucia
 */
public class Persona {
    //Definicion de atributos de la clase
    public String nombre;
    public String genero;
    public String apellido;
    public String ocupacion;
    public void desplegarInformacion(){
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido:" + apellido);
    }
}

    