package palabrathis;

/**
 *
 * @author Lucia
 */
public class PalabraThis {

    public static void main(String[] args) {
        Persona persona = new Persona("Pepe", "Perez");
        System.out.println("persona: " + persona);
        System.out.println("persona nombre: " + persona.nombre);
        System.out.println("persona apellido: "+ persona.apellido);
    }
    
}

class Persona{
    String nombre;
    String apellido;
    
    Persona(String nombre, String apellido){
        super();
        this.nombre = nombre;
        this.apellido = apellido;
        System.out.println("objeto persona usando this " + this);
        new Imprimir().imprimir(this);
        
    }
}

class Imprimir{
    
    public Imprimir(){
        super(); //el constructor de la clase padre reserva
    }
    public void imprimir(Persona persona){
        System.out.println("persona desde imprimir:" + persona);
        System.out.println("impresion del objeto actual:" + this);
    }
}
