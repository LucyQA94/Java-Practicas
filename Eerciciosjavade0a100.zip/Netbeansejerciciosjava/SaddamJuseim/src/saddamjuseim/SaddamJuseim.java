package saddamjuseim;

/**
 *
 * @author Lucia
 */
public class SaddamJuseim {

    public static void main(String[] args) {
        var escribirenespañol = true;
        var escribireningles = false;
        
        if(escribirenespañol = true){
            System.out.println("Saddam juseim se tira a tu cuello");
        }
        else{
        System.out.println("Saddam sonrie y se va");
        }
}
    }
    
