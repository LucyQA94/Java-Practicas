
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 *
 * @author Lucia
 */
public class CCuentaAhorro extends CCuenta {
    
    //Miembros dato
    private double cuotaMantenimiento;
    
    //Constructores
    public CCuentaAhorro(String nombreTitular, String numCuenta, double saldo, double tipoInteres, double cuotaMantenimiento)
    {
        super(nombreTitular, numCuenta, saldo, tipoInteres);
        this.cuotaMantenimiento = cuotaMantenimiento;
    }
    
    public CCuentaAhorro()
    {
    }
    
    public void setCuotaMantenimiento(double cuotaMantenimiento)
    {
        this.cuotaMantenimiento = cuotaMantenimiento;
    }
    public double getCuotaMantenimiento()
    {
        return cuotaMantenimiento;
    }
    
    public void comisiones()
	{
		GregorianCalendar fecha = new GregorianCalendar();
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		
		if(dia == 1)
			reintegro(cuotaMantenimiento);
	}
        
        public double intereses()
        {
            GregorianCalendar fecha = new GregorianCalendar();
            int dia = fecha.get(Calendar.DAY_OF_MONTH);
            double intereses = 0.0;
        if(dia == 1)
        {
            intereses = (getsaldo() * gettipoInteres()) / 12;
            ingreso(intereses);
        }
        
        return intereses;

     }
}
    
    
