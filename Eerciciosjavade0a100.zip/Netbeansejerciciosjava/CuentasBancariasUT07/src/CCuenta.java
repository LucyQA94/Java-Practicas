/**
 *
 * @author Lucia
 */
public abstract class CCuenta {

        //Miembros dato
        private String nombreTitular;
        private String numCuenta;
        private double saldo;
        private double tipoInteres;
        
        //Constructores
        public CCuenta(String nombreTitular, String numCuenta, double saldo, double tipoInteres)
        {
            this.nombreTitular = nombreTitular;
            this.numCuenta = numCuenta;
            ingreso(saldo);
            this.tipoInteres = tipoInteres;
        }
        public CCuenta()
        {
        }
        
        //Metodos Set
        public void setNombreTitular(String nombreTitular)
        {
            this.nombreTitular = nombreTitular;
        }
        public void setnumCuenta(String numCuenta){
            this.numCuenta = numCuenta;
        }
        public void settipoInteres (double tipoInteres){
            this.tipoInteres = tipoInteres;
        }
       
        //Metodos Get
        public String getNombreTitular()
        {
            return nombreTitular;
        }
        public String getnumCuenta(){
            return numCuenta;
        }
        public double gettipoInteres(){
            return tipoInteres;
        }
        public double getsaldo(){
            return saldo;
        }
        
        public abstract void comisiones();
        
        public void ingreso(double cantidad)
        {
            if (cantidad <= 0){
                System.out.println("La cantidad a ingresar debe ser mayor a 0");
            }
            else{
                saldo = saldo + cantidad;
            }
        }
        public void reintegro(double cantidad)
        {
            if(cantidad > saldo){
                System.out.println("El Saldo que hay en su cuenta no es suficiente");
            }
            else{
                saldo = saldo - cantidad;
            }
        }
        
    }
    

