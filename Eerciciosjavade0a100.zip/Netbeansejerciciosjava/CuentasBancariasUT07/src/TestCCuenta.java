/**
 *
 * @author Lucia
 */
public class TestCCuenta
{
	public static void main(String[] args){
    	CCuentaAhorro cliente01 = new CCuentaAhorro("Lucia", "222/7777", 10000, 3.5, 30);

    	System.out.println(cliente01.getNombreTitular());
    	System.out.println(cliente01.getnumCuenta());
    	System.out.println(cliente01.getsaldo());
    	System.out.println(cliente01.gettipoInteres());
    	System.out.println(cliente01.intereses());

    	CCuentaCorrienteConIn cliente02 = new CCuentaCorrienteConIn();
    	
    	cliente02.setNombreTitular("PACA");
    	cliente02.setnumCuenta("1234567890");
    	cliente02.settipoInteres(3.0);
    	cliente02.setTransExentas(0);
    	cliente02.setImportePorTrans(1.0);
    	
    	cliente02.ingreso(20000);
    	cliente02.reintegro(10000);
    	cliente02.intereses();
    	cliente02.comisiones();
    	
    	System.out.println();
    	System.out.println(cliente02.getNombreTitular());
    	System.out.println(cliente02.getnumCuenta());
    	System.out.println(cliente02.getsaldo());
	}
}
