package operaciones;
/**
 *
 * @author Lucia
 */
public class Aritmetica {
    //atributos de la clase
    int a;
    int b;
    
    //Constructor vacio
    public Aritmetica(){
        System.out.println("Ejecutando constructor");
        
    }
    
    public Aritmetica(int arg1, int arg2){
        this.a = a;
        this.b = b;
        System.out.println("Ejecutando constructo de argumentos");
    }
    
    //Metodo
    public void sumar(){
      int resultado = a + b;
        System.out.println("resultado = " + resultado);
    }
        public int sumarConRetorno(){
        //int resultado = a + b;
        //return resultado;
        return a + b;
    }
    public int sumarConArgumentos(int arg1, int arg2){
        a = arg1;
        b = arg2;
        //return a + b;
        return sumarConRetorno();
        
    }
    
}
