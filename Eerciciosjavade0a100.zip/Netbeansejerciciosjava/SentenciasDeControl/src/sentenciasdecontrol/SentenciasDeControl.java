package sentenciasdecontrol;
/**
 *
 * @author Lucia
 */
public class SentenciasDeControl {
    public static void main(String[] args) {
        var condicion = true;
        
        if(condicion == true){
            System.out.println("La condicion es verdadera");
        }
        else{
            System.out.println("La condicion no es verdadera");
        }
        
        var numero = 2;
        var numerotexto ="Numero desconocido";
        
        if(numero == 1){
            numerotexto = "Numero uno";
        }
        
        else if(numero == 2){
            numerotexto = "Numero dos";
            
        }
        else if(numero == 3){
            numerotexto = "Numero tres";
        }
        
         else if(numero == 4){
            numerotexto = "Numero cuatro";
        }
        
        else {
            System.out.println("Numero no encontrado");
        }
    }
    
}
