/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sentenciasdecontrol;

/**
 *
 * @author Lucia
 */
public class SwitchJava {
    public static void main(String[] args) {
        var numero = 2;
        var numeroTexto = "Valor desconecido";
        
        switch(numero){
            case 1: 
                numeroTexto = "Numero uno";
            break;
            case 2:
                numeroTexto = "Numero dos";
            case 3:
                numeroTexto = "Numero tres";
                break;
            case 4:
                numeroTexto = "Numero cuatro";
                break;
            default:
                numeroTexto= "Caso no encontrado";
        }
        System.out.println("NumeroTexto =" + numeroTexto);
    }
}
