package sentenciasdecontrol;

/**
 *
 * @author Lucia
 */
public class SistemaCalificaciones {
    public static void main(String[] args){
        
        var numeroCalificacion = 10;
        var calificacion = "Letra desconocida";
        
        switch(numeroCalificacion){
            case 0: case 1: case 2: case 3: case 4: case 5:
                calificacion ="F";
                break;
                
            case 6: 
                calificacion = "D";
                break;
            case 7:
                calificacion = "C";
                break;
            case 8:
                calificacion = "B";
            case 9: case 10:
                calificacion = "A";
                break;
                
            default: 
                calificacion = "Numero desconocido";
        }
        System.out.println("La letra de la calificacion es:" + calificacion);
    }
}
