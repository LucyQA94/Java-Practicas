/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sentenciasdecontrol;

/**
 *
 * @author Lucia
 */
public class EstacionDelAño {
    public static void main(String[] args){
        var mes = 4;
        var estacion = "Estacion desconocida";
        switch(mes){
            case 1: case 2: case 13:
                estacion ="Invierno";
                break;
           case 3: case 4: case 5:
               estacion = "Primavera";
               break;
           case 6: case 7: case 8:
               estacion = "Verano";
           case 9: case 10: case 11:
               estacion = "Otoño";
        }
        System.out.println("estacion:" + estacion);
    }
}
