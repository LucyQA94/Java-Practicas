import java.util.Scanner;

public class caracteresespeciales {

    public static void main(String args[]) {
        var nombre = "Lucy";


        System.out.prinln("Nueva linea: \n" + nombre);


    }
}