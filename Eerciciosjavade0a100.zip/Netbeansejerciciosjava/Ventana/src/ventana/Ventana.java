package ventana;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;

/**
 *
 * @author Lucia
 */
public class Ventana extends JFrame {
    public Ventana(){
       setSize(800, 500);
       setTitle("Parque automovilistico Alcalá de Henares");
       this.setDefaultCloseOperation(EXIT_ON_CLOSE);
       this.setMinimumSize(new Dimension(200,200));
       this.setMaximumSize(new Dimension(900,800));
       this.getContentPane().setBackground(Color.red);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana v = new Ventana();
        v.setVisible(true);
    }
    
}
