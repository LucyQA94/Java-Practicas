/**
 *
 * @author Lucia
 */
        class TestPilasColasDinamicas {
	public static void main(String args[])
	{
		ColaDinamica Cola = new ColaDinamica();
		ColaDinamica interfaz = Cola;
		
		for(char car = 'a'; car <= 'z'; car++)
		{
			Character caracter = new Character(car);
			interfaz.insertar(caracter);
		}
		
		while(!interfaz.vacia())
		{
			Character caracter = (Character)interfaz.eliminar();
			char car = caracter.charValue();
			System.out.print("" + car);
		}
		
		System.out.println("\n");
		
		PilaDinamica pila = new PilaDinamica();
		PilaDinamica interfaz = pila;
		
		for(char car = 'a'; car <= 'z'; car++)
		{
			Character caracter = new Character(car);
			interfaz.insertar(caracter);
		}
		
		while(!interfaz.vacia())
		{
			Character caracter = (Character)interfaz.eliminar();
			char car = caracter.charValue();
			System.out.print("" + car);
		}
		
		System.out.println("\n");
	}
}