/**
 *
 * @author Lucia
 */
public interface PilasColasDinamicas {
    public abstract boolean vacia();
	public abstract void insertar(Object obj);
	public abstract Object eliminar();
}
