import java.util.Scanner;
/*
*Task UT3 Person-class
*Person-Class Proyect
*Name: Lucía Hidalgo Manzanares
*/

public class Persona{
    
    String Nombre;
    int edad;
    float altura;
    
    string consulta_Nombre(){
        return Nombre;
    }

        public String cambia_Nombre(String n){
            return Nombre;
        }
    
    
public static void main(String[] args) {

    //Create person object
    Persona persona=new persona();

    //Create keyboard object
    teclado teclado=new teclado();

    //Data input
    System.out.println("Introduce el nombre de la persona");
    String nom=teclado.nextLine();

    //Modification of data
    persona.cambia_Nombre(nom);

    //Output data
    System.out.println("El nombre de la persona es:"+ nom);

    }

}