package manejoarchivos;
import java.io.*;

/**
 *
 * @author Lucia
 */
public class BorrarArchivos {
    public static void borrarArchivos(String nombreArchivo){
    File archivo = new File(nombreArchivo);
        if (archivo.delete()){
        System.out.println("El fichero ha sido borrado satisfactoriamente");
        }
        else{
        System.out.println("El fichero no puede ser borrado");
        }
    }
}
