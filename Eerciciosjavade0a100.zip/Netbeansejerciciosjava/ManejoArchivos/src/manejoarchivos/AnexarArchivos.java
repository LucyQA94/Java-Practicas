package manejoarchivos;
import java.io.*;
/**
 *
 * @author Lucia
 */
public class AnexarArchivos {
    //Esto lo que hace es crear una nueva clase que anexa el contenido del archivo, por lo cual no se sobreescribe la información que queramos añadir
    public static void anexarArchivo(String nombreArchivo, String contenido) throws IOException {
        File archivo = new File(nombreArchivo);
        try {
            PrintWriter salida = new PrintWriter(new FileWriter(archivo, true));
            salida.println(contenido);
            salida.close();
            System.out.println("Se ha anexado en el archivo");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
    }
}
