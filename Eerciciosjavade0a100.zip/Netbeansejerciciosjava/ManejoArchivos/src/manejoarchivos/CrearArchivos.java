package manejoarchivos;
import java.io.*;
/**
 *
 * @author Lucia
 */

//Esta clase crea el archivo, podemos añadirle la ubicacion del archivo dentro del test crear archivo, recuerda las // dobles para windows
public class CrearArchivos {
    public static void crearArchivo(String nombreArchivo){
        File archivo = new File(nombreArchivo);
        try{
            PrintWriter salida = new PrintWriter(archivo);
            salida.close();
            System.out.println("Se ha creado el archivo");
        }catch (FileNotFoundException ex){
            ex.printStackTrace(System.out);
        }
        
    }
}
