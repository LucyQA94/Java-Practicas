package test;

import static manejoarchivos.EscribirArchivos.escribirArchivo;

/**
 *
 * @author Lucia
 */
public class TestEscribirArchivo {
    public static void main(String[] args) {
        var nombreArchivo = "prueba.txt";
        escribirArchivo(nombreArchivo, "Hola desde Java");
    }
}
