package test;
import static manejoarchivos.CrearArchivos.crearArchivo;
/**
 *
 * @author Lucia
 */
public class TestCrearArchivos {
    public static void main(String[] args) {
        var nombreArchivo = "prueba.txt";
        crearArchivo(nombreArchivo);
    }
}
