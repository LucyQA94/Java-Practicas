package test;

import java.io.IOException;
import static manejoarchivos.LeerArchivos.leerArchivo;

/**
 *
 * @author Lucia
 */
public class TestLeerArchivos {
    public static void main(String[] args) throws IOException {
        var nombreArchivo = "prueba.txt";
        leerArchivo(nombreArchivo); 

    }
}
