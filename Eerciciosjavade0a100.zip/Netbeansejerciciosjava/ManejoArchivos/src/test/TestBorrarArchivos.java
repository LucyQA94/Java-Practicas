package test;

import static manejoarchivos.BorrarArchivos.borrarArchivos;

/**
 *
 * @author Lucia
 */
public class TestBorrarArchivos {
    public static void main(String[] args) {
        var nombreArchivo = "prueba.txt";
        borrarArchivos(nombreArchivo);
    }
}
