package test;
import java.io.IOException;
import static manejoarchivos.AnexarArchivos.anexarArchivo;

/**
 *
 * @author Lucia
 */
public class TestAnexarArchivos {
    public static void main(String[] args) throws IOException {
        var nombreArchivo = "prueba.txt";
        anexarArchivo (nombreArchivo, "Adios desde Netbeans, Lucy está convirtiendose en programadora");
        anexarArchivo (nombreArchivo, "Creo que me gusta más javascript :D ");
    }
}
