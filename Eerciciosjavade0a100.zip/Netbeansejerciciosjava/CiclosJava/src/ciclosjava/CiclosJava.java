package ciclosjava;

/**
 *
 * @author Lucia
 */
public class CiclosJava {

    public static void main(String[] args) {
        var contador = 0;
        while( contador < 3) {
            System.out.println("contador = " + contador);
            contador++;
        }
    }
    
}
