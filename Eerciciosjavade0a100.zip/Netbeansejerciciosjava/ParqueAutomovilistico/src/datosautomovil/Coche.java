package datosautomovil;

import java.sql.Connection;

/**
 *
 * @author Lucia
 */
public class Coche {
    public String matricula;
    public String nombrePropietario;
    public String numBastidor;
    public String impuestoCirculacion;
    public boolean impuestoCirculacionPagado; 
}
