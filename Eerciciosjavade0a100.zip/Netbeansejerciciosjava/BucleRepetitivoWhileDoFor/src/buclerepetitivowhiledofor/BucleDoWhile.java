/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buclerepetitivowhiledofor;

/**
 * Bucle Do While
 * @author Lucia
 */
public class BucleDoWhile {
    public static void main(String args[])
    {
    int i=1;
    System.out.println("Numeros del 1 al 100");
    do{
        System.out.println(i);
       i++;
    }while(i<=100);
    }
}
