/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buclerepetitivowhiledofor;

/**
 * Bucle For
 * @author Lucia
 */
public class BucleFor {
    public static void main(String args[]){
        System.out.println("Numeros del 1 al 100: ");
        for(int i  = 1; i<=100; i++)
            System.out.println(i);
            
            }    
}
