/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buclerepetitivowhiledofor;

/**
 *
 * @author Lucia
 */
public class BucleWhile {
    public static void main(String[] args) {
        System.out.println("Numeros del 1 al 100: ");
        int i=1;
        while(i<=100) {
            System.out.println("i");
            i++;
        } 
    }
}
