import lombok.Data;

import java.util.Scanner;

/**
 * @author Lucía Hidalgo
 */
@Data
public class ArrayDouble {

    private int array [];

    //Default constructor
    public ArrayDouble(){

        System.out.println("Enter  the array length");
        int length = getInputKeyboard();
        array = new int[length];

    }

    //Constructor with arrayLenght
    public ArrayDouble(int arrayLenght){

        array = new int[arrayLenght];

    }

    //Copy constructor
    public ArrayDouble(int[] array) {
        this.array = array;
    }



    //Methods

    //Method implemented to read input values and store them into the array
    public void leerArray() {

        Scanner teclado = new Scanner(System.in);

        for (int i = 0; i < array.length; i++) {

            System.out.print("\nInsert new value in position: " + i + "\n");

            array[i] = teclado.nextInt();

            if (array[i] == 999) {
                System.out.print("It won't store more values");
                break;
            }
        }

        System.out.print("All values are stored\n");
    }

    //Method escribirArray to show the array values
    public void escribirArray() {

        for (int i = 0; i < array.length; i++) {

            System.out.print("Posición " + i + " es " + array[i]);

        }
    }

    //Method to insert a new value into the array by position
    public void insertar(){

        System.out.print("\nInsert the selected position in the array: ");
        int position = getInputKeyboard();

        if(position >= 0 || position < array.length){

            //Ask user to input a new value
            int value = getInputKeyboard();

            array[position] = value;

        } else {
            System.out.print("It is not a valid position! ");
        }

    }

    //Method eliminar to delete a stored value
    public void eliminar(){

        System.out.print("\nInsert the selected position in the array: ");
        int position = getInputKeyboard();

        if(position >= 0 || position < array.length){

          array[position] = 0;

        } else {
            System.out.print("It is not a valid position! ");
        }

    }

    //Method busquedaSecuencial to search a value sequentially
    public void busquedaSecuencialv1(){

        System.out.print("\nInsert a value to search: ");
        int valueToSearch = getInputKeyboard();
        boolean valueFound = false;

        for (int position = 0; position < array.length; position++) {

            if(valueToSearch == array[position]){
                valueFound = true;
                System.out.println("value found in position: " + position + " of the array\n\n");
                break;
            }

        }

        if(valueFound == false){
            System.out.println("-1");
        }

    }

    //Method busquedaSecuencial to search a value sequentially
    public void busquedaSecuencialv2(){

        System.out.print("\nInsert a value to search: ");
        int valueToSearch = getInputKeyboard();
        boolean valueFound = false;

        for (int position = array.length-1; position >= 0; position--) {

            if(valueToSearch == array[position]){
                valueFound = true;
                System.out.println("value found in position: " + position + " of the array\n\n");
                break;
            }

        }

        if(valueFound == false){
            System.out.println("-1");
        }

    }

    //Method busquedaSecuencial to search a value sequentially
    public void busquedaSecuencialv3(){

        System.out.print("\nInsert a value to search: ");
        int valueToSearch = getInputKeyboard();

        for(int position=0;;position++)
            if(array[position]==valueToSearch)
                break;

    }

    //Method busquedaBinaria to search a value
    public void busquedaBinaria(){

        System.out.print("\nInsert a value to search: ");
        int valueToSearch = getInputKeyboard();

        int from,to,middle,position;

        // Dar valor a elemento.
        for(from=0,to = array.length; from<=to;)
        {
            if(from==to) // si el array sólo tiene un elemento:
            {
                if(array[from]==valueToSearch) // si es la solución:
                    position=from; // darle el valor.
                else // si no es el valor:
                    position=-1; // no está en el array.
                break; // Salir del bucle.
            }
            middle=(from+to)/2; // Divide el array en dos.
            if(array[middle]==valueToSearch) // Si coincide con el central:
            {
                position=middle; // ese es la solución
                break; // y sale del bucle.
            }
            else
            if(array[middle]>valueToSearch) // si es menor:
                to=middle-1; // elige el array de la izquierda.
            else // y si es mayor:
                from=middle+1; // elige el array de la derecha.
        }

    }

    public void maximo(){

        double max = array[0];
        int maxPosition = 0;

        for (int i = 1; i < array.length; i++)
            if (array[i] > max){
                max = array[i];
                maxPosition = i;
            }

        System.out.println("Max value: " + max + ", in position: " + maxPosition + " of the array");

    }

    public void minimo(){

        double min = array[0];
        int minPosition = 0;

        for (int i = 1; i < array.length; i++)
            if (array[i] < min){
                min = array[i];
                minPosition = i;
            }

        System.out.println("Min value: " + min + ", in position: " + minPosition + " of the array");

    }

    public void ordenaBurbuja(){

        int n = array.length;
        int temp = 0;
        for(int i=0; i < n; i++){
            for(int j=1; j < (n-i); j++){
                if(array[j-1] > array[j]){
                    //swap elements
                    temp = array[j-1];
                    array[j-1] = array[j];
                    array[j] = temp;
                }
            }
        }
        escribirArray();

    }

    public int[] fusion(int[] array1, int[] array2){


        int [] r = new int [array1.length + array2.length];
        int ia = 0, ib = 0;
        while (ia < array1.length) {
            r[ia] = array1[ia];
            ia++;
        }
        while (ib < array2.length) {
            r[ia + ib] = array2[ib];
            ib++;
        }

        return r;
    }

    public void paresImpares(){

        int par = 0;
        int impar = 0;

        for(int position=0; position < array.length; position++){

            if(array[position]%2==0){
                par++;
            } else{
                impar++;
            }

        }

        System.out.println("Ammount of par values: " + par);
        System.out.println("Ammount of impar values: " + impar);

    }

    public void media(){

        double mean = 0;

        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0){
                mean = mean + array[i];
            }
        }

        System.out.println("The array mean is " + mean);

    }

    //Method used to read input values from keyboard
    private int getInputKeyboard(){
        Scanner keyboard = new Scanner(System.in);
        return keyboard.nextInt();

    }


}
