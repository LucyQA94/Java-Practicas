
import java.util.Scanner;


/**
 *
 * @author Lucia Hidalgo
 */
public class TareaLibro {
    public static void main (String[] args) {
        //all needed here
        System.out.println("Proporciona el titulo");
        Scanner consola = new Scanner(System.in);
        var titulolibro = consola.nextLine();
        System.out.println("titulo del libro = " +  titulolibro);
        System.out.println("Proporciona el autor");
        var autorlibro = consola.nextLine();
        System.out.println("autor del libro = " +  autorlibro);
        System.out.println("Resultado: " + titulolibro + " " + autorlibro);
    }
    
}
