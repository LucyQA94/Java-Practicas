package extra21;

/**
 *
 * @author Lucia
 */
public interface AlPeso {

    public double calcularPrecio(int peso);
    
}
