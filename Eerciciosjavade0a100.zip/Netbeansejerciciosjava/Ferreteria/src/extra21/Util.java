package extra21;
import java.util.Scanner;
/**
 *
 * @author Lucia
 */
public class Util {

    public static int leerInt()
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                return sc.nextInt();
            }
            catch (Exception e)
            {
                sc.nextLine();
            }
        }
    }
    public static String leerLinea()
    {
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }

    public static double leerDouble()
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                return sc.nextDouble();
            }
            catch (Exception e)
            {
                sc.nextLine();
            }
        }
    }
    
}
