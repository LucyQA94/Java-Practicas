package extra21;
/**
 *
 * @author Lucia
 */
public class PUnidad extends Producto{

    public PUnidad(int c, String d, double p)
    {
        super(c,d,p);
    }
    

    @Override
    public String toString()
    {
        return codigo+"\t"+desc+"\t"+precio+"€/unidad";
    }
    
}
