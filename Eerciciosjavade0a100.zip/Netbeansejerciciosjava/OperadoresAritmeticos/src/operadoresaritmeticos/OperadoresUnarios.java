/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operadoresaritmeticos;

/**
 *
 * @author Lucia
 */
public class OperadoresUnarios {
    public static void main(String args[]){
        int a = 3;
        var b = -a;
        System.out.println("a ="+ a);
        System.out.println("b ="+ b);
        
        var c = true;
        var d = !c;
        System.out.println("c =" + c);
        System.out.println("b = " + b);
//incremento
//l.preincremento (simbolo antes de la variable)

    var e = 3;
    var f = ++e; //primero se incrementa la variable y despues se usa su valor
        System.out.println("e = "+ e);
        System.out.println("f =" + f);
        
    //2. postincremento (simbolo despues de la variable)
    var g = 5;
    var h = g++;//primero se usa la g y luego se incrementa
        System.out.println("g =" +g);
        System.out.println("h = " +h);
        
        //decremento
        //primer paso predecremento (primero encuentra el operador)
        var i = 2;
        var j = --i;
        System.out.println("i = "+ i);//ya está decrementada
        System.out.println("j ="+ j);
        
        //segundo paso postdecremento
        var k = 4;
        var l = k--; //primero se usa el valor de la variable y queda pendiente decremento
        System.out.println("k ="+ k); //tenia pendiente el decremento
        System.out.println("l =" +l);
    }
    
}
