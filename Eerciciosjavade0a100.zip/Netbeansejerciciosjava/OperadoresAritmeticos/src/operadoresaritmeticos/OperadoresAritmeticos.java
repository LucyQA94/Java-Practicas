package operadoresaritmeticos;

/**
 *Operadores aritmeticos
 * @author Lucia
 */
public class OperadoresAritmeticos {
    public static void main(String[] args) {
       int a=3, b=2;
       var resultado = a + b;
        System.out.println("resultado de la suma="+ resultado);
        
        resultado = a - b;
        System.out.println("resultado de la resta= " + resultado);
        
        resultado = a * b;
        System.out.println("resultado de la multiplicación =" + resultado);
        
        var resultado2 = 3D/ b;
        System.out.println("resultado division ="+ resultado2);
        
        resultado = a % b;
        System.out.println("resultado modulo = " + resultado);
        
        if(a % 2 == 0)
            System.out.println("Es numero par");
        else
            System.out.println("Es numero impar");
        
        if(b % 2 == 0)
            System.out.println("Es numero par");
        else
            System.out.println("Es numero impar");
        
    }
    
}
