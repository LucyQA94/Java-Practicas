/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operadoresaritmeticos;

/**
 *
 * @author Lucia
 */
public class OperadoresDeIgualdad {
    public static void main(String args[]){
        var a = 3;
        var b = 2;
        //comparativa de si son iguales a y b
        var c = (a == b);
        System.out.println("c ="+ c);
        //comparativa de si son diferentes a y b
        var d = a!=b;
        System.out.println("d= " + d);
        
        //cadenas
        var cadena = "Hola";
        var cadena2= "Adios";
        var e= cadena == cadena2;
        System.out.println("e =" + e);
        
        var f = cadena.equals(cadena2); //comparamos contenido de cadenas
        System.out.println("f =" +f);
        
        //operadores relacionales
        var g = a > b;
        System.out.println("g ="+ g);
        
        if( a % 2 == 0 ) {
            System.out.println("Es numero par");
        }
        
        else{
            System.out.println("Es numero impar");
    }
        var edad = 30;
        var adulto = 18;
        
        if (edad <= adulto){
            System.out.println("Es un adulto");
        }
        else {
            System.out.println("Es menor de edad");
        }
    }   
}
