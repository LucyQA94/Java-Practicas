/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operadoresaritmeticos;

/**
 *
 * @author Lucia
 */
public class OperadoresDeAsignacion {
    public static void main(String args[]){
       int a =3, b=2;
       int c = a + 5 - b;
        System.out.println("c ="+ c);
        
        a += 1;//a = a + 1
        System.out.println("a =" + a);
        
        a += 3; //a = a + 3
        System.out.println("a ="+ a);
        
        a -=2;//a = a - 2
        System.out.println("a =" + a);
        
        a *=2;//a = a * 2
        System.out.println("a =" + a);
        
        a /=2;//a = a / 2
        System.out.println("a =" + a);
        
        a %=2;//a = a % 2
        System.out.println("a =" + a);
    }
}
