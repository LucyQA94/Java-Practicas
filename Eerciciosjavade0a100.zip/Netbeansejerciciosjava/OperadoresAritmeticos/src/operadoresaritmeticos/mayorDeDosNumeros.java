package operadoresaritmeticos;

import java.util.Scanner;

/**
 *
 * @author Lucia
 */
public class mayorDeDosNumeros {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Añada un número");
        int numero1 = Integer.parseInt(scanner.nextLine());
        System.out.println("Añada el segundo número");
        int numero2 = Integer.parseInt(scanner.nextLine());
        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        }
        else{
       System.out.println("El número 1 es menor que el numero 2");
           
    }
}
}
