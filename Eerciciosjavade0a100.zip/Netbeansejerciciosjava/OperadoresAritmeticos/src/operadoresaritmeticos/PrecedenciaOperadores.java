/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operadoresaritmeticos;

/**
 *
 * @author Lucia
 */
public class PrecedenciaOperadores {
    public static void main(String args[]){
        var x = 5;
        var y = 10;
        var z = ++x + y--;
        //++ es un preincremento - suma 1 // -- es un postdecremento - en este caso se decrementa después y devuelve 10.
        System.out.println("z es igual a: " + z); // imprime 16
        System.out.println("x es igual a: " + x); // imprime 6
        System.out.println("y es igual a: " + y); // imprime 9
        
        var resultado = 4 + 5 * 6 / 3; //esto es evaluado con preferencia hacia la derecha y es prioritario la multiplicacion y luego
        //la división. Después es evaluada la suma y si hubiera una resta también sería evaluada.
        System.out.println("resultado =" + resultado);
        
        var resultado2 = (4 + 5) * 6 /3;
        
        System.out.println("resultado2 =" + resultado2);
    }
}
