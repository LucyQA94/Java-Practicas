package test;

import domain.Empleado;

/**
 *
 * @author Lucia
 */
public class TestHerencia {
    public static void main(String[] args) {
        Empleado empleado1 = new Empleado("Juan", 5000.0);
        System.out.println("empleado1 = " + empleado1);
        
    }
}
