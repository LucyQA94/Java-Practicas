package test;
import domain.Cliente;
import java.util.Date;
/**
 *
 * @author Lucia
 */
public class TestHerenciaCliente {
    public static void main(String[] args) {
       
       var fecha = new Date(); 
        Cliente cliente1 = new Cliente(fecha, true, "Lucy", 'F', 28, "Desengaño 24");
        System.out.println(" Cliente 1= " + cliente1);
    }
}
