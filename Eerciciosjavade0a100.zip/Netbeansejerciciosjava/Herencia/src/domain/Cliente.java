package domain;
import java.util.Date;
/**
 *
 * @author Lucia
 */
public class Cliente extends Persona {
    protected int idCliente;
    protected Date fechaRegistro;
    protected boolean Vip;
    protected static int contadorCliente;
    protected boolean idVip;

    public Cliente (Date fechaRegistro, boolean Vip, String nombre, char genero, int edad, String direccion){
        super(nombre, genero, edad, direccion);
        this.idCliente = ++Cliente.contadorCliente;
        this.fechaRegistro = fechaRegistro;
        this.Vip = Vip;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isVip() {
        return Vip;
    }

    public void setVip(boolean Vip) {
        this.Vip = Vip;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Cliente{");
        sb.append("idCliente=").append(idCliente);
        sb.append(", fechaRegistro=").append(fechaRegistro);
        sb.append(", Vip=").append(Vip);
        sb.append(", ").append(super.toString());
        sb.append('}');
        return sb.toString();
    }
    

}

