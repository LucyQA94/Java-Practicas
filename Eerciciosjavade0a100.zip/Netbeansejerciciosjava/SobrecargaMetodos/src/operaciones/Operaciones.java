package operaciones;
/**
 *
 * @author Lucia
 */
public class Operaciones {
    
    public static int sumar(int a, int b){
        return a + b;
    }
    
    public static double sumar(double a, double b){
        return a + b;
    }
}
