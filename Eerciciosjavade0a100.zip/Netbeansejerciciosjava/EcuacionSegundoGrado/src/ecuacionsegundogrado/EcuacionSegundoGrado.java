/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecuacionsegundogrado;

import java.util.Scanner;

/**
 *
 * @author Lucia
 */
public class EcuacionSegundoGrado {
public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        try {
    	System.out.println("Introduce el coeficiente 'a': ");
        double coeficienteA = sc.nextDouble();
    	System.out.println("Introduce el coeficiente 'b': ");
        double coeficienteB = sc.nextDouble();
    	System.out.println("Introduce el coeficiente 'c': ");
        double coeficienteC = sc.nextDouble();
        double discriminante;
        double resultado1;
        double resultado2;
        
        if(coeficienteA == 0 && coeficienteB == 0) {
        	throw new ErrorEcuacionDegenerada();
        }
        
        if (coeficienteB != 0 && coeficienteC != 0) {
        	discriminante = (coeficienteB * coeficienteB) - 4 * coeficienteA * coeficienteC;
        	if(discriminante > 0) {
        		resultado1 = ((-coeficienteB) + Math.sqrt(discriminante)) / (2 * coeficienteA);
        		resultado2 = ((-coeficienteB) - Math.sqrt(discriminante)) / (2 * coeficienteA);
        		System.out.printf("Resultado: Dos soluciones reales distintas x = %f, x = %f", resultado1, resultado2);
        	} else if (discriminante == 0) {
        		resultado1 = (-coeficienteB) / (2 * coeficienteA);
        		System.out.printf("Resultado: Dos soluciones reales iguales x = %f", resultado1);
        	} else {
        		// Fragmento Tarea 8 Inicio
        		throw new ErrorRaizCompleja();
        		// Fragmento Tarea 8 Fin
        	}
        }
        
        if (coeficienteB == 0 && coeficienteC != 0) {
        	resultado1 = Math.sqrt( (-coeficienteC / coeficienteA));
        	resultado2 = -Math.sqrt( (-coeficienteC / coeficienteA));
        	if(resultado1 < 0 || resultado2 < 0) {
        		System.out.printf("Resultado: Dos soluciones reales distintas x = %f, x = %f", resultado1, resultado2);
        	} else {
        		System.out.printf("Resultado: La ecuacion no tiene soluciones reales (hay dos soluciones complejas distintas).");
        	}
        }
        
        if (coeficienteC == 0 && coeficienteB != 0) {
        	resultado1 = -coeficienteB / coeficienteA;
        	System.out.printf("Resultado: Dos soluciones distintas x = 0, x = %f", resultado1);
        }
        
        if (coeficienteB == 0 && coeficienteC == 0 ) {

        	System.out.print("Resultado: Solucion unica x = 0");
        }
        }catch(ErrorEcuacionDegenerada e){
        	System.out.println("Error, ecuacion degenerada");
        }catch(ErrorRaizCompleja e){
    		System.out.println("La ecuacion no tiene soluciones (hay dos soluciones complejas distintas).");
    	}
    }
}

class ErrorEcuacionDegenerada extends Exception
{
	public ErrorEcuacionDegenerada()
	{
		super();
	}
}

class ErrorRaizCompleja extends Exception
{
	public ErrorRaizCompleja()
	{
		super();
	}
}    

