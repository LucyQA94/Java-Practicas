package allcodehere;

/**
 * Inferencia de tipos primitivos con Var y Primitivos
 * @author Lucia
 */
public class InferenciadetiposConVaryPrimitivos {
    public static void main(String args[]) {
        //añade una variable de tipo entero INT
        var numeroEntero = 10;
        //imprime la variable de tipo entero INT
        System.out.println("Numero Enttero = " + numeroEntero);
        
        var numeroDouble = 10.0;
        System.out.println("numeroDouble =" + numeroDouble);
        
        var numeroFloat = 10.0F;
        System.out.println("numeroFloat =" + numeroFloat);
    }
    
}
