/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package allcodehere;

import java.util.Scanner;

/**
 *
 * @author Lucia
 */
public class TiendaDeLibros {
    public static void main(String args[]){
     //Se requiere el nombre
    Scanner scanner = new Scanner(System.in);
    System.out.println("Proporciona el nombre");
    String nombre = scanner.nextLine();
     //Se requiere el ID
    System.out.println("Proporciona el ID");
    int id = Integer.parseInt(scanner.nextLine());
    //Se requiere el precio
    System.out.println("Proporciona el precio");
    double precio = Double.parseDouble(scanner.nextLine());
    //Se requiere el dato de envio gratuito tipo boolean
    System.out.println("Proporciona el envio gratuito(true o false)");
    boolean envioGratuito = Boolean.parseBoolean(scanner.nextLine());
    
    System.out.println(nombre + " #" + id);
    System.out.println("Precio: $" + precio);
    System.out.println("Envio Gratuito:" + envioGratuito);
        
        
    }
}
