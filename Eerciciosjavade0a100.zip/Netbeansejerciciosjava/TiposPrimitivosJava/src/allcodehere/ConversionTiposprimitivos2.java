/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package allcodehere;

import java.util.Scanner;

/**
 *
 * @author Lucia
 */
public class ConversionTiposprimitivos2 {
 
    public static void main(String args[]){
        var edadTexto = String.valueOf(10);
        System.out.println("edadTexto= " + edadTexto);
        
        var caracter = "hola".charAt(1);
        System.out.println("caracter=" + caracter);
        
        System.out.println("Proporciona un caracter:");
        var consola = new Scanner(System.in);
        caracter = consola.nextLine().charAt(0);
        System.out.println("caracter =" + caracter);
    }
}
