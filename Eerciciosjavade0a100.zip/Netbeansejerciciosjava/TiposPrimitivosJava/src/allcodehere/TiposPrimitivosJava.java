package allcodehere;

/**
 *
 * @author Lucia Hidalgo
 */
public class TiposPrimitivosJava {
    public static void main(String args[]) {
    /*
    tipos primitivos enteros: byte, short, int, long    
    */    
    
    byte numeroByte = (byte)129;
        System.out.println("Valor byte" + numeroByte);
        System.out.println("valor minimo del byte:" + Byte.MIN_VALUE);
        System.out.println("Valor maximo del byte:" + Byte.MAX_VALUE);
        
        short numeroShort = (short)32768;
        System.out.println("numeroShort = " + numeroShort);
        System.out.println("valor minimo del short:" + Short.MIN_VALUE);
        System.out.println("Valor maximo del short:" + Short.MAX_VALUE);
        
        int numeroInt= (int) 2147483649L;
        System.out.println("numeroInt = " + numeroInt);
        System.out.println("valor minimo del int:" + Integer.MIN_VALUE);
        System.out.println("Valor maximo del int:" + Integer.MAX_VALUE);
        
        long numeroLong = 9223372036854775807L;
        System.out.println("numeroLong:" + Long.MIN_VALUE);
        System.out.println("numeroLongmaximo;" + Long.MAX_VALUE);

    }
}
