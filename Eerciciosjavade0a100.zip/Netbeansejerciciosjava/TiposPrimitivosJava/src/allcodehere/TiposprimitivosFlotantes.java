package allcodehere;


/**
 *Tipos primitivos flotantes (float 32bits) - (double 64bits)
 * @author Lucia Hidalgo
 */
public class TiposprimitivosFlotantes {
   public static void main(String args[]) {
     float numeroFloat= (float)3.4028235E38;
       System.out.println("numeroFloat= " + numeroFloat);
       System.out.println("Valor minimo tipo float" + Float.MIN_VALUE);
       System.out.println("Valor minimo tipo float" + Float.MAX_VALUE);
       
       double numeroDouble = 1.7976931348623157E308;
       System.out.println("numeroDouble=" + numeroDouble);
       System.out.println("Valor minimo tipo Double" + Double.MIN_VALUE);
       System.out.println("Valor minimo tipo Double" + Double.MAX_VALUE);
   } 
}
