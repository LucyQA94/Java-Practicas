/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package allcodehere;

/**
 *
 * @author Lucia
 */
public class TiposPrimitivosChar {
    public static void main(String args[]){
        char miCaracter = 'a';
        System.out.println("miCaracter =" + miCaracter);
        
    var varChar1 = '\u0021';
        System.out.println("varChar1 =" + varChar1);
        
    var varCharDecimal2 = 33;
        System.out.println("varChar Decimal2 = " + varCharDecimal2);
        
    var varCharSimbolo3 = '!';
        System.out.println("varCharDecimal3 =" + varCharSimbolo3);
        
    int variableEnteraSimbolo = '!';
        System.out.println("variable de tipo entero con Simbolo =" + variableEnteraSimbolo );
        
    int letra = 'A';
        System.out.println("letra =" + letra);
       
    }
    
}
