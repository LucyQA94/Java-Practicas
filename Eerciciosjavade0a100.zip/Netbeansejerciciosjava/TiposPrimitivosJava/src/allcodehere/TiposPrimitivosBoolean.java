package allcodehere;

/**
 *Tipos primitivos de tipo Boolean
 * @author Lucia
 */
public class TiposPrimitivosBoolean {
    public static void main(String args[]){
        //se añade variable de tipo boolean, la cual usa true o false
      boolean varBoolean = true;
      //se imprime la variable
        System.out.println("variable booleana es igual a =" + varBoolean);
        
        //utilización de un if para validar si la variable Boolean contiene el valor true
        //if realiza la comprobación de la variable
        if(varBoolean){
            //imprimimos la comprobación del if para la variable
            System.out.println("La variable boolean es verdadera");
            //se añade un else para verificar que si no es verdadera se muestre como que es falso
        }
            else{
                    System.out.println("La variablle boolean es falsa");
                    }
        //creamos una variable para saber si una persona es mayor de edad
            var edad = 10;
            //se añade una variable para la comprobación de igual o mayor de 18
            //var esAdulto = edad >= 18;
            //Sin embargo se puede setear la variable edad directamente en el if y hacer la comparación de menor de edad
            if (edad >= 18){
                System.out.println("Eres mayor de edad");
            }
            else{
                System.out.println("Eres menor de edad");
            }
        }
    }
