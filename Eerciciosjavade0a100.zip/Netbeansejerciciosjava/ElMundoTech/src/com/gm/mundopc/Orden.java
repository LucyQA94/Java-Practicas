package com.gm.mundopc;

/**
 *
 * @author Lucia
 */
//Creamos la clase Orden, que será publica pero los elementos privados
public class Orden {

    private final int idOrden;
    private Computadora computadoras[]; //Creamos el array
    private static int contadorOrdenes;
    private static int contadorComputadoras;
    private static final int MAX_COMPUTADORAS = 10;

//Creamos el constructor
    public Orden() {
        this.idOrden = ++Orden.contadorOrdenes;
        this.computadoras = new Computadora[Orden.MAX_COMPUTADORAS];

    }
    public void mostrarOrden(){
        System.out.println("El orden es:" + this.idOrden);
        System.out.println("Computadoras de la Orden:"+ this.idOrden);
        for (int i = 0; i < Orden.contadorOrdenes; i++) {
            System.out.println(this.computadoras[i]);
        }
    }
    //Agregamos un metodo que agrega computadoras

    public void agregarComputadora(Computadora computadora) {
        if (this.contadorComputadoras < Orden.MAX_COMPUTADORAS) {
            computadoras[contadorComputadoras++] = computadora;
        } else {
            System.out.println(Orden.MAX_COMPUTADORAS + "Se ha llenado un maximo de computadoras, no es posible continuar");
        }
    }
}
